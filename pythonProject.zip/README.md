# Escape-from-capybara
# Read instructions on the main menu
# Follow the instructions
# Use WASD to move
